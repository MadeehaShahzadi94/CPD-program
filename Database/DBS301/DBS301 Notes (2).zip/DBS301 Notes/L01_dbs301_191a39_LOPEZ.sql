-- ***********************
-- Name: Krystyna Lopez
-- ID: 146736178
-- Date: January 11, 2019
-- Purpose: Lab 1 DBS301
-- ***********************

-- Question 1 �-	Which one of these tables appeared to be the widest? or longest? 
-- Q1 Solution -- To find the answer to this question we will run commands to check the the number of columns and number of
-- rows in the tables
-- SELECT * FROM employees;
-- SELECT * FROM departments;
-- SELECT * FROM job_history;
-- The table Employees is the widest table and the longest one. Employees table consist of 11 columns and 20 rows
-- while tables departments and job_history consist of 4 columns and 8 rows, and 5 columns and 10 rows accordingly.

SELECT * FROM employees;
SELECT * FROM departments;
SELECT * FROM job_history;

-- Question 2 -- If the following SELECT statement does NOT execute successfully, how would you fix it?
-- SELECT last_name �LName�, job_id �Job Title�, 
--        Hire Date �Job Start�
--        FROM employees;

-- Q2 Solution -- There are several mistakes: 1) we need to put the name of columns exact the same as the name in the table
-- Hire Date should be Hire_Date. When output the columns with new names we have to put "as"
-- SELECT last_name as "LName", job_id as "Job Title", 
--      Hire_Date as "Job Start"
--      FROM employees;
       
SELECT last_name as "LName", job_id as "Job Title", 
       Hire_Date as "Job Start"
       FROM employees;
       
-- Question 3 -- There are THREE coding errors in this statement. Identify them.
-- Then, correct them and provide a working statement.

-- SELECT employee_id, last name, commission_pct Emp Comm,
--      FROM employees;

-- Q3 Solution -- 1) Last name in the employee table written as last_name and in the command last name 
-- (this is give us a different names). Names of the columns in the table must match the name of the column in the command
-- 2) If we want for the user output change the name of the column we must use "as" 
-- 3) Put the new name into the qoutes if we use spaces in the name of the column or as in this case underline and scip qoutes.

-- SELECT employee_id, last_name, commission_pct as Emp_Comm
--       FROM employees;

SELECT employee_id, last_name, commission_pct as Emp_Comm
         FROM employees;
         
--Question 4 -- What command would show the structure of the LOCATIONS table?

--Q4 Solution 1)
-- SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_DEFAULT, COLUMN_ID 
--      FROM ALL_TAB_COLUMNS 
--      WHERE TABLE_NAME='LOCATIONS';

SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_DEFAULT, COLUMN_ID 
        FROM ALL_TAB_COLUMNS 
        WHERE TABLE_NAME='LOCATIONS';

-- Q4 Solution 2)
-- DESC LOCATIONS;

DESC LOCATIONS;

--Question 5 -- Create a query to display the output shown below. 
--Q5 Solution --
-- SELECT LOCATION_ID as "City#", City,
--    STATE_PROVINCE||' ' ||'IN THE'|| ' ' ||COUNTRY_ID as "Province with Country Code"
--    FROM LOCATIONS;

SELECT LOCATION_ID as "City#", City,
      STATE_PROVINCE||' ' ||'IN THE'|| ' ' ||COUNTRY_ID as "Province with Country Code"
      FROM LOCATIONS;


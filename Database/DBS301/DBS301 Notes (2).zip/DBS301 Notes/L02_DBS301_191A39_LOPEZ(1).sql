-- ***********************
-- Name: Krystyna Lopez
-- ID: 146736178
-- Date: Jan 15, 2019
-- Purpose: Lab 2 DBS301
-- ***********************

-- Q1: Display the employee_id, last name and salary of employees earning in the range of $8,000 to $12,000.  
-- Sort the output by top salaries first and then by last name.

--Q1 Answer:
SELECT      employee_id, last_name, TO_CHAR(salary,'$999,999.99') AS "Salary"
    FROM    employees
    WHERE   salary>=8000 AND salary<=12000
    ORDER BY salary DESC, last_name;

--Q2: Modify previous query (#1) so that additional condition is to display only if they work as Programmers or 
--Sales Representatives. Use same sorting as before.

--Q2 Answer:
SELECT      employee_id, last_name, TO_CHAR(salary,'$999,999.99') AS "Salary"
    FROM    employees
    WHERE   salary>=8000 AND salary<=12000 AND (job_id='IT_PROG' OR job_id='SA_REP')
    ORDER BY salary DESC, last_name;
    
-- Q3: The Human Resources department wants to find high salary and low salary employees. 
-- Modify previous query (#2) so that it displays the same job titles but for people who earn outside the given 
-- salary range from question 1. Use same sorting as before.

--Q3 Answer:
SELECT      employee_id, last_name, TO_CHAR(salary,'$999,999.99') AS "Salary"
    FROM    employees
    WHERE   (salary<8000 OR salary>12000) AND (job_id='IT_PROG' OR job_id='SA_REP')
    ORDER BY salary DESC, last_name;
    
-- Q4: The company needs a list of long term employees, in order to give them a thank you dinner. 
-- Display the last name, job_id and salary of employees hired before 2018. List the most recently hired employees first.

-- Q4 Answer:
SELECT      last_name, job_id, TO_CHAR(salary,'$999,999.99') AS "Salary"
    FROM    employees
    WHERE   hire_date< TO_DATE('2018-01-01','YYYY-DD-MM')
    ORDER BY hire_date DESC;
    
-- Q5: Modify previous query (#4) so that it displays only employees earning more than $12,000. 
-- List the output by job title alphabetically and then by highest paid employees.
    
-- Q5 Answer:
SELECT      last_name, job_id, TO_CHAR(salary,'$999,999.99') AS "Salary"
    FROM    employees
    WHERE   hire_date< TO_DATE('2018-01-01','YYYY-DD-MM') AND salary>12000
    ORDER BY job_id, salary DESC;

-- Q6: Display the job titles and full names of employees whose first name contains an �e� or �E� anywhere. 
-- The output should look like: (BONUS MARK FOR NOT using the OR keyword in the solution but obtaining the same results)

-- Q6 Answer:
SELECT      job_id, first_name||' '||last_name AS "Full name"
    FROM    employees
    WHERE   UPPER(first_name) LIKE '%E%'
    ORDER BY job_id;
    
-- Q7: Create a report to display last name, salary, and commission percent for all employees that earn a commission.

-- Q7 Answer:
SELECT      last_name AS "Last name", TO_CHAR(salary,'$999,999.99') AS "Salary", commission_pct AS "Commission"
    FROM    employees
    WHERE   commission_pct IS NOT NULL;

-- Q8: Create a report to display last name, salary, and commission percent for all employees that earn a commission. 
-- Put the report in order of descending salaries.

-- Q8 Answer:
SELECT      last_name AS "Last name", TO_CHAR(salary,'$999,999.99') AS "Salary", commission_pct AS "Commission"
    FROM    employees
    WHERE   commission_pct IS NOT NULL
    ORDER BY salary DESC;

-- Q9: Create a report to display last name, salary, and commission percent for all employees that earn a commission. 
-- Put the report in order of descending salaries, but use a numeric value instead of a column name to do the sorting.
-- Why using numeric values in sorting is not a good idea. 

-- Q9 Answer:
-- Sorting by numeric values instead of column way is not a good idea because it is not efficient and don't look profesional
-- Second: if we need to correct our SELECT statement and we add columns before our column that we are sorting by
-- Command will not give correct output. We can look at the arguments in the select statement as elements of an array. 
-- If we add columns the numeration will change

SELECT last_name AS "Last name", TO_CHAR(salary,'$999,999.99') AS "Salary", commission_pct AS "Commission"
    FROM employees
    WHERE commission_pct IS NOT NULL
    ORDER BY 2 DESC;
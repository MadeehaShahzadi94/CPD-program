
-- ------Name Rabia Khalid--


-- -----Student No: 134420173


-- ----Dbs301 Lab 7 Operators

--

-------- Task 1 ----------

SELECT department_id
FROM departments
MINUS
SELECT department_id
FROM employees
WHERE UPPER(job_id) = UPPER('ST_CLERK')
ORDER BY department_id;


---------------------------------------------
--------------------------------------------
--------------------------------------------
--------Task 2------------
---2.Same department requests a list of countries 
--that have no departments located in them.
-- Display country ID and the country name. 
--Use SET operators.  
----------------------------------------------


--------Task 3 ------------
SELECT DISTINCT job_id, department_id
FROM employees
WHERE department_id = 10

UNION ALL

SELECT DISTINCT job_id, department_id
FROM employees
WHERE department_id = 50

UNION ALL

SELECT DISTINCT job_id, department_id
FROM employees
WHERE department_id = 20;

--------Task 4 ----------

SELECT employee_id, job_id
FROM employees

INTERSECT

SELECT employee_id, job_id
FROM job_history
ORDER BY 1;
--------Task 5-----------
select last_name,department_id,TO_CHAR('null')
from employees
union
select TO_CHAR('null'),department_id,department_name
from departments
order by 1
